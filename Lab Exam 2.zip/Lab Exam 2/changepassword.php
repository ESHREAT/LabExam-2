<?php

	session_start();
	
	$rpass = $username = $cpass = $npass ="";
	
	$iserror = 0;
	
	if(isset($_POST['click']))
	{
		if(isset($_POST['cpass']))
		{
			$cpass = trim($_POST['cpass']);
		}
		else
		{
			$iserror = 1 ;
			$errcpass = "this box can not be empty";
		}

		if(isset($_POST['npass']))
		{
			$npass = trim($_POST['npass']);
		}
		else
		{
			$iserror = 1 ;
			$errnpass = "this box can not be empty";
		}
		if(isset($_POST['rpass']))
		{
			$rpass = trim($_POST['rpass']);

			if($npass != $rpass)
			{
				$iserror = 1;
				$errrpass = "must be match";
			}
		}
		else
		{
			$iserror = 1 ;
			$errrpass = "this box can not be empty";
		}

		$username = $_SESSION['username'];

		if(iserror == 0)
		{
			$db = mysqli_connect("localhost","root","","reg");
			$query = "update user set password = '$npass' where username='$username' ";

			mysqli_query($db,$query);

			header("Location:loggedin.php");
		}

	}

?>

<!DOCTYPE html>
<html>
	<head>
		<title>Admin Home page</title>
	</head>
	<body>
		<fieldset>
			<legend><b>CHANGE PASSWORD</b></legend>
			<form>
				<table>
					<tr>
						<td><font size="3">Current Password</font></td>
						<td>:</td>
						<td><input type="password" name = "pass"/></td>
						<td></td>
					</tr>
					<tr>
						<td><font size="3" color="green">New Password</font></td>
						<td>:</td>
						<td><input type="password" name="npass"/></td>
						<td></td>
					</tr>
					<tr>
						<td><font size="3" color="red">Retype New Password</font></td>
						<td>:</td>
						<td><input type="password" name="rpass"/></td>
						<td></td>
					</tr>
				</table>
				<hr />
				<input type="submit" value="Submit" name="click" />
			</form>
		</fieldset>
	</body>
</html>