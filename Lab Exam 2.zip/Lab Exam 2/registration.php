<?php

	$name = $email = $pass = $cpass = $username = $gender = $date = $month = $year = $picture = "";
	$iserror = 0 ;
 
	if(isset($_POST['submit']))
	{
		if(isset($_POST['name']))
		{
			$name = trim($_POST['name']);
		}
		else
		{
			$iserror = 1 ;
		}
		
		if(isset($_POST['email']))
		{
			$email = trim($_POST['email']);
		}
		else
		{
			$iserror = 1 ;
		}
		if(isset($_POST['pass']))
		{
			$pass = trim($_POST['pass']);
		}
		else
		{
			$iserror = 1 ;
		}
		if(isset($_POST['cpass']))
		{
			$cpass = trim($_POST['cpass']);
			
			if($pass != $cpass)
			{
				$iserror = 1;
			}
		}
		else
		{
			$iserror = 1 ;
		}
		if(isset($_POST['username']))
		{
			$username = trim($_POST['username']);
		}
		else
		{
			$iserror = 1 ;
		}
		if(!(isset($_POST['gender'])))
		{
			$iserror = 1;
		}
		if(isset($_POST['date']))
		{
			$date = trim($_POST['date']);
		}
		else
		{
			$iserror = 1 ;
		}
		if(isset($_POST['month']))
		{
			$month = trim($_POST['month']);
		}
		else
		{
			$iserror = 1 ;
		}
		if(isset($_POST['year']))
		{
			$year = trim($_POST['year']);
		}
		else
		{
			$iserror = 1 ;
		}
		
		if($iserror == 0 )
		{
			$db = mysqli_connect("localhost","root","","reg");
			$query = "insert into user values('$name','$email','$pass','$username','$gender','$picture','$date','$month','$year')" ;

			mysqli_query($db , $query);  //registration completed

			header("Location:login.php");  //go to login page
		}
	}

?>


<!DOCTYPE html>
<html>
	<head>
		<title>Registration</title>
	</head>
	<body>
		<fieldset>
			<legend><b>REGISTRATION</b></legend>
			<form method = "post" action="#">
				<br/>
				<table width="100%" cellpadding="0" cellspacing="0">
					<tr>
						<td>Name</td>
						<td>:</td>
						<td><input name="name" type="text" ></td>
						<td></td>
					</tr>		
					<tr><td colspan="4"><hr/></td></tr>
					<tr>
						<td>Email</td>
						<td>:</td>
						<td>
							<input name="email" type="text">
							<abbr title="hint: sample@example.com"><b>i</b></abbr>
						</td>
						<td></td>
					</tr>		
					<tr><td colspan="4"><hr/></td></tr>
					<tr>
						<td>User Name</td>
						<td>:</td>
						<td><input name="username" type="text"></td>
						<td></td>
					</tr>		
					<tr><td colspan="4"><hr/></td></tr>
					<tr>
						<td>Password</td>
						<td>:</td>
						<td><input name="pass" type="password"></td>
						<td></td>
					</tr>		
					<tr><td colspan="4"><hr/></td></tr>
					<tr>
						<td>Confirm Password</td>
						<td>:</td>
						<td><input name="cpass" type="password"></td>
						<td></td>
					</tr>		
					<tr><td colspan="4"><hr/></td></tr>
					<tr>
						<td colspan="3">
							<fieldset>
								<legend>Gender</legend>    
								<input name="gender" type="radio">Male
								<input name="gender" type="radio">Female
								<input name="gender" type="radio">Other
							</fieldset>
						</td>
						<td></td>
					</tr>		
					<tr><td colspan="4"><hr/></td></tr>
					<tr>
						<td colspan="3">
							<fieldset>
								<legend>Date of Birth</legend>    
								<input type="text" size="2" name ="date"/>/
								<input type="text" size="2" name="month"/>/
								<input type="text" size="4" name="year"/>
								<font size="2"><i>(dd/mm/yyyy)</i></font>
							</fieldset>
						</td>
						<td></td>
					</tr>
				</table>
				<hr/>
				<input type="submit" value="Submit" name="submit">
				<input type="reset">
			</form>
		</fieldset>
	</body>
</html>