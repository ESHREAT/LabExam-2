<?php

	session_start();

	$username = $pass  = "";
	$iserror = 0 ;
	$notfound = "";

	if(isset($_POST['login']))
	{
		if(isset($_POST['username']))
		{
			$username = $_POST['username'];
		}
		else
		{
			$iserror = 1 ;
		}

		if(isset($_POST['pass'])){
			$pass = $_POST['pass'];
		}
		else
		{
			$iserror = 1 ;
		}

		if($iserror == 0)
		{
			$db = mysqli_connect("localhost","root","","reg");

			$query = " select * from user where username='$username' AND password='$pass' ";

			$alldata = mysqli_query($db,$query);

			if(mysqli_num_rows($alldata) == 1)
			{
				while($user = mysqli_fetch_assoc($alldata))
				{
					$_SESSION['username'] = $user['username'];
					$_SESSION['name'] = $user['name'];
					$_SESSION['pass'] = $user['password'];
				}
				
				header("Location:loggedin.php"); //send to homepage
			}
			else
			{
				echo "not found";
				$notfound = "Id or Password dont match";
			}
		}
	}

?>

<!DOCTYPE html>
<html>
	<head>
		<title>Log In</title>
	</head>
	<body>
		<fieldset>
			<legend><b>LOGIN</b></legend>
			<form method="post" action="#">
				<table>
					<tr>
						<td>User Name</td>
						<td>:</td>
						<td><input type="text" name="username"></td>
					</tr>
					<tr>
						<td>Password</td>
						<td>:</td>
						<td><input type="password" name="pass"></td>
					</tr>
				</table>
				<hr />
				<input name="remember" type="checkbox">Remember Me
				<br/><br/>
				<input type="submit" value="Submit" name="login">        
				<a href="#">Forgot Password?</a>
			</form>
		</fieldset>
	</body>
</html>